"""
RoboArt
~~~~~~~~~~~~~~~~~~~

A basic random avatar generator 

:copyright: (c) 2023 puang59
:license: MIT, see LICENSE for more details.

"""

__title__ = 'robotart'
__author__ = 'puang59'
__license__ = 'MIT'
__copyright__ = 'Copyright 2023 puang59'
__version__ = '0.0.1'

from .HashFaces import roboart
